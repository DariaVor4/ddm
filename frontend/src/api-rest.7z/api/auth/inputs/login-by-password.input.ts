export interface ILoginByPasswordInput {
  email: string;
  password: string;
}
