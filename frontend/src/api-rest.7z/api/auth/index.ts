import axiosClient from '../axios-client';
import { IAccessTokenResponse } from './responses/access-token.response';
import { ILoginByPasswordInput } from './inputs/login-by-password.input';

export default {
  loginByPassword: (body: ILoginByPasswordInput) => axiosClient.post<IAccessTokenResponse>('registration/emailAvailability', body),
  refreshTokens: () => axiosClient.post<IAccessTokenResponse>('registration/refreshTokens'),
};
