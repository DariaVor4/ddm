export interface EmailAvailabilityResponse {
  verdict: 'ok' | 'incorrect' | 'occupied';
  message: string;
}
