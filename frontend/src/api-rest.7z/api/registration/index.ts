import axiosClient from '../axios-client';
import { EmailAvailabilityResponse } from './responses/email-availability.response';
import { IEmailConfirmByCodeInput } from './inputs/email-confirm-by-code.input';

export default {
  emailAvailability: (email: string) => axiosClient.post<EmailAvailabilityResponse>('registration/emailAvailability', { email }).then(({ data }) => data),
  sendConfirmationCode: (email: string) => axiosClient.post<{ registrationTimeOut: number }>('registration/sendConfirmationCode', { email }).then(({ data }) => data),
  emailConfirmByCode: (body: IEmailConfirmByCodeInput) => axiosClient.post<boolean>('registration/emailConfirmByCode', body).then(({ data }) => data),
};
