export interface IEmailConfirmByCodeInput {
  email: string;
  code: string;
}
