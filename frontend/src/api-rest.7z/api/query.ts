/* eslint-disable react-hooks/rules-of-hooks */
import { useMutation } from '@tanstack/react-query';
import api from './api';

export default {
  /* Registration */
  emailAvailability: () => useMutation({
    mutationKey: ['emailAvailability'],
    mutationFn: api.registration.emailAvailability,
  }),
  sendConfirmationCode: () => useMutation({
    mutationKey: ['sendConfirmationCode'],
    mutationFn: api.registration.sendConfirmationCode,
  }),
  emailConfirmByCode: () => useMutation({
    mutationKey: ['emailConfirmByCode'],
    mutationFn: api.registration.emailConfirmByCode,
  }),
  /* Auth */
  loginByPassword: () => useMutation({
    mutationKey: ['loginByPassword'],
    mutationFn: api.auth.loginByPassword,
  }),
  refreshTokens: () => useMutation({
    mutationKey: ['refreshTokens'],
    mutationFn: api.auth.refreshTokens,
  }),
  /* Student */
  studentRegistration: () => useMutation({
    mutationKey: ['studentRegistration'],
    mutationFn: api.student.registration,
  }),
};
