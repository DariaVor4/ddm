/**
 * Model Student
 * Студент
 */
export type Student = {
  id: string
  /**
   * Телефон
   */
  phone: string | null
  /**
   * Куратор
   */
  curator: string | null
  /**
   * Факультет
   */
  faculty: string | null
  /**
   * Курс
   */
  course: number | null
  /**
   * Группа
   */
  group: string | null
  createdAt: Date
  updatedAt: Date | null
  deletedAt: Date | null
};
