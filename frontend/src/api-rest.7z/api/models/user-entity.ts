import { Student } from './student-entity';
import { Employee } from './employee-entity';

/**
 * Model User
 * Пользователь
 */
export type User = {
  /**
   * Идентификатор пользователя
   */
  id: string
  /**
   * Электронная почта (должна быть подтверждена)
   */
  email: string
  /**
   * Bcrypt хэш пароля
   */
  password: string
  /**
   * Авторизован ли сейчас пользователь?
   */
  tokenHash: string | null
  /**
   * Последняя активность
   */
  lastActivity: Date | null
  student: Student | null
  employee: Employee | null
  createdAt: Date
  updatedAt: Date | null
  deletedAt: Date | null
};
