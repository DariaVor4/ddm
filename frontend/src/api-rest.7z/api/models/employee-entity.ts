export type Employee = {
  id: string
  /**
   * Фамилия
   */
  lastName: string | null
  /**
   * Имя
   */
  firstName: string | null
  /**
   * Отчество
   */
  patronymic: string | null
  /**
   * Является ли админом?
   */
  isAdmin: boolean
  createdAt: Date
  updatedAt: Date | null
  deletedAt: Date | null
};
