import axios from 'axios';

const axiosClient = axios.create({
  baseURL: import.meta.env.VITE_API_ENDPOINT,
  headers: {
    'Content-Type': 'application/json',
  },
  withCredentials: true,
});

// TODO: Добавить мидлвари обновления токена
// axiosClient.interceptors.response.use(
//   response => response,
//   error => {
//     if (error.response?.status === 401) {
//       window.location.href = '/';
//     }
//   },
// );

export default axiosClient;
