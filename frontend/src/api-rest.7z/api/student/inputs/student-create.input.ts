/**
 * Данные для создания студента.
 */
export interface IStudentCreateInput {
  email: string;
  password: string;
  phone?: string;
  lastName: string;
  firstName: string;
  patronymic?: string;
  curator?: string;
  faculty?: string;
  course?: number;
  group?: string;
}
