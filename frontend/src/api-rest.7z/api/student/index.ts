import axiosClient from '../axios-client';
import { IStudentCreateInput } from './inputs/student-create.input';

export default {
  registration: (body: IStudentCreateInput) => axiosClient.post<boolean>('student/registration', body).then(({ data }) => data),
};
