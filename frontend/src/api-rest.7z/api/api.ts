import auth from './auth';
import registration from './registration';
import student from './student';

export default {
  auth,
  registration,
  student,
};
