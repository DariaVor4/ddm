import axiosClient from '../axios-client';
import { User } from '../models/user-entity';

export default {
  me: () => axiosClient.get<User>('user/me').then(({ data }) => data),
};
